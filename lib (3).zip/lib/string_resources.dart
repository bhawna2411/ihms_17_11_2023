class StringRes {
  static const token = "token";
}
