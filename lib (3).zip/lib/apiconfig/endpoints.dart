class endpoints {
  // var base_url = "http://143.110.244.110/ihms/api";
  // var base_url = "http://admin.ihmsclubs.com/api";
  var base_url = "http://143.110.184.198/ihms/api";

  var splacescreen = '/splashscreen';
  var amenities = '/amenitieslist';
  var clubs = '/clubs';
  var whatsnew = '/whatsnew';
  var userProfile = '/profile/';
  var services = '/conciergeserviceslist';
  var activities = '/activitieslist';
  
  var eventhistory = '/eventhistory';
  var concierge = '/concierge';
  var amenitiesHistory = '/amenities_history';


  var banner = '/banner';
  var society = '/society';
  var social_url = '/social_url';
  var static_page = '/static_pages';
  var event = '/event';
  var generateId = '/requestaddcash';
  var participate = '/paid_event_participate';
  var availableSeat = '/availableEvent';
  var addtransaction = '/addTransactionDetail';
  var users = '/users';
  var login = '/login';
  var imageUploadUser = '/imageUploadUser';
  var tower = '/tower';
  var flat = '/flat';
  var sendotp = '/send-otp';
  var bookService = '/book_service';
  var participateEvents = '/event_participate';
  var submitotp = '/submit-otp';
  var register = '/register';
  var pendingrequest = '/pending_event_request';
  var sendfeedback = '/sendFeedback';
  var userprofileupdate = '/user-profile-update';
   var viewCount = '/view_count';
  var clickCount = '/click_count';
  var amenityParticipate = '/amenity_participate';
  var switchUserSociety = '/switch_user_society';
}
